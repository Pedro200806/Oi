package com.cotemig.prova

data class Carro(
    val id: Int,
    val modelo: String,
    val marca: String,
    val ano: Int,
    val descricao: String
)
