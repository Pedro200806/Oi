package com.cotemig.prova

import kotlinx.coroutines.delay

object CarroRepository {
    private val itens = listOf(
        Carro(1, "Fusca", "Volkswagen", 1970, "Ícone brasileiro, motor traseiro refrigerado a ar."),
        Carro(2, "Gol", "Volkswagen", 1995, "Compacto mais vendido do país por décadas."),
        Carro(3, "Uno", "Fiat", 1990, "Hatch pequeno e econômico."),
        Carro(4, "Corolla", "Toyota", 2020, "Sedã médio conhecido pela confiabilidade."),
        Carro(5, "Onix", "Chevrolet", 2018, "Hatch moderno e campeão de vendas.")
    )

    // Simula uma chamada de rede: roda fora da Main e demora um pouco
    suspend fun listar(): List<Carro> {
        delay(300)
        return itens
    }

    suspend fun buscarPorId(id: Int): Carro? {
        delay(800)
        return itens.find { it.id == id }
    }
}
