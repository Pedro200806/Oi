package com.cotemig.prova

import androidx.lifecycle.ViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

class CarroViewModel : ViewModel() {
    // TODO (B): a lista de carros deve ser carregada e exposta aqui

    private val _favoritoIds = MutableStateFlow<Set<Int>>(emptySet())
    val favoritoIds: StateFlow<Set<Int>> = _favoritoIds.asStateFlow()

    suspend fun buscarCarro(id: Int): Carro? = CarroRepository.buscarPorId(id)

    fun alternarFavorito(id: Int) {
        _favoritoIds.update { if (id in it) it - id else it + id }
    }
}
