package com.cotemig.prova.userinterface

import androidx.compose.runtime.Composable
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.toRoute
import com.cotemig.prova.viewmodel.CarroViewModel
import kotlinx.serialization.Serializable

@Serializable
sealed interface Rota {
    @Serializable
    data object Lista : Rota

    @Serializable
    data class Detalhe(val carroId: Int) : Rota
}

@Composable
fun AppNavigation() {
    val navController = rememberNavController()
    val viewModel: CarroViewModel = viewModel()

    NavHost(navController = navController, startDestination = Rota.Lista) {
        composable<Rota.Lista> {
            ListaCarroScreen(
                viewModel = viewModel,
                aoClicar = { id -> navController.navigate(Rota.Detalhe(id)) }
            )
        }
        composable<Rota.Detalhe> { backStackEntry ->
            val rota = backStackEntry.toRoute<Rota.Detalhe>()
            DetalheCarroScreen(
                viewModel = viewModel,
                carroId = rota.carroId,
                aoVoltar = { navController.popBackStack() }
            )
        }
    }
}
