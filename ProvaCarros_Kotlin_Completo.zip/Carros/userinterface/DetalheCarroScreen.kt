package com.cotemig.prova.userinterface

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.cotemig.prova.data.Carro
import com.cotemig.prova.viewmodel.CarroViewModel

@Composable
fun DetalheCarroScreen(
    viewModel: CarroViewModel,
    carroId: Int,
    aoVoltar: () -> Unit
) {
    var carro by remember(carroId) { mutableStateOf<Carro?>(null) }
    val favoritos by viewModel.favoritoIds.collectAsState()

    LaunchedEffect(carroId) {
        carro = viewModel.buscarCarro(carroId)
    }

    if (carro == null) {
        Column(
            modifier = Modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            CircularProgressIndicator()
        }
    } else {
        val item = carro!!
        Column(
            modifier = Modifier.fillMaxSize().padding(24.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(item.modelo, style = MaterialTheme.typography.headlineLarge)
            Spacer(Modifier.height(16.dp))
            Text("Marca: ${item.marca}")
            Text("Ano: ${item.ano}")
            Text("Descrição: ${item.descricao}")
            Spacer(Modifier.height(24.dp))
            Button(onClick = { viewModel.alternarFavorito(item.id) }) {
                Text(if (item.id in favoritos) "★ Favorito" else "☆ Favoritar")
            }
            Spacer(Modifier.height(8.dp))
            Button(onClick = aoVoltar) {
                Text("← Voltar")
            }
        }
    }
}
