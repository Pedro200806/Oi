package com.cotemig.prova

import androidx.compose.material3.Text
import androidx.compose.runtime.Composable

@Composable
fun DetalheCarroScreen(viewModel: CarroViewModel, carroId: Int, aoVoltar: () -> Unit) {
    // TODO (C): implemente a tela conforme o enunciado da prova.
    Text("TODO")
}
