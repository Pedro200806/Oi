package com.cotemig.prova.viewmodel

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.cotemig.prova.data.Carro
import com.cotemig.prova.data.CarroRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

class CarroViewModel : ViewModel() {
    var carros by mutableStateOf<List<Carro>>(emptyList())
        private set

    private val _favoritoIds = MutableStateFlow<Set<Int>>(emptySet())
    val favoritoIds: StateFlow<Set<Int>> = _favoritoIds.asStateFlow()

    init {
        viewModelScope.launch {
            carros = CarroRepository.listar()
        }
    }

    suspend fun buscarCarro(id: Int): Carro? = CarroRepository.buscarPorId(id)

    fun alternarFavorito(id: Int) {
        _favoritoIds.update { favoritos ->
            if (id in favoritos) favoritos - id else favoritos + id
        }
    }
}
